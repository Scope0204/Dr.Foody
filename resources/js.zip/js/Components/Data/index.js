import Data from './Data';

export default Data;
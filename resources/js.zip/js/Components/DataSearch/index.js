import DataSearch from "./DataSearch";

export default DataSearch;
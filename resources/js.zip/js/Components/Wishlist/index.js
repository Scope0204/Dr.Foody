import Wishlist from './Wishlist';

export default Wishlist;
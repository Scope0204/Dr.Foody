import React from 'react';

const Store = React.createContext();

export default Store;
